﻿namespace ContentstackAssetImporter
{
    public class Program
    {
        public static void Main(string[] args)
        {
            new AssetListProcessor().Process(@"c:\temp\assets.csv");
        }
    }
}
