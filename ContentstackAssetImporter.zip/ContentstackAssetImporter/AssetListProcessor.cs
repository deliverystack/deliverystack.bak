﻿namespace ContentstackAssetImporter
{
    using System;
    using System.IO;
    using System.Linq;
    using System.Net;

    using Newtonsoft.Json.Linq;

    using Microsoft.VisualBasic.FileIO;
    using System.Collections.Generic;

    public class AssetListProcessor
    {
        // map existing folder UIDs to names for constructing folder paths
        // dictionary will contain entries for all existing folders
        private Dictionary<string, string> _folderIdsToNames = new Dictionary<string, string>();

        // map existing folder UIDs to their parent folder UIDs 
        // dictionary will first contain entries for all existing folders
        // then add new folders mapping to null
        // then create new folders and update mapping
        private Dictionary<string, string> _folderIdsToParentIds = new Dictionary<string, string>();

        // map folder paths to folder UIDs 
        // dictionary will first contain entries for all folders in the CSV
        // and their ancestors mapping to null
        // then updated to IDs of existing folders
        // then create new folders as reqiored for CSV data and update mapping
        private SortedList<string, string> _folderPathsToIds = new SortedList<string, string>();

        // map all required folder paths to null in _folderPathsToIds
        private void MapPathsToNull(string csv)
        {
            using (TextFieldParser parser = new TextFieldParser(csv))
            {
                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(",");
                string headings = parser.ReadLine();

                if (!(String.Equals(headings, "filepath,title,description,folderpath,tags", StringComparison.InvariantCultureIgnoreCase)))
                {
                    Console.WriteLine("Header row (columns) must be FilePath,Title,Description,FolderPath,Tags.");
                    Environment.Exit(2);
                }

                while (!parser.EndOfData)
                {
                    string path = parser.ReadFields()[3].TrimStart('/').TrimEnd('/').ToLower();

                    if (String.IsNullOrWhiteSpace(path))
                    {
                        continue;
                    }

                    _folderPathsToIds[path] = null;

                    // ancestors
                    while (path.Contains("/"))
                    {
                        path = path.Substring(0, path.LastIndexOf("/"));

                        if (!_folderPathsToIds.ContainsKey(path))
                        {
                            _folderPathsToIds[path] = null;
                        }
                    }
                }
            }
        }

        // update _folderPathsToIds with information about existing folders
        private void AddExistingFolderData()
        {
            int processed = 0; // count folders processed to determine whether to request the next page
            int limit = 100; // return data in pages of 100 folders (Contentstack limit)
            int totalFolders = -1; // total number of folders to process, determined on first HTTP call

            // page through 100 folders at a time
            do
            {
                // get data about all existing folders
                // https://www.contentstack.com/docs/developers/apis/content-management-api/#get-a-single-folder
                string url = "https://api.contentstack.io/v3/assets?include_folders=true&query={\"is_dir\":true}&limit="
                    + limit
                    + "&skip="
                    + processed;

                // get the count of all folders on the first request
                if (totalFolders < 0)
                {
                    url += "&include_count=true";
                }

                // get a page of folder data
                JObject queryResult = JObject.Parse(new HttpRequestProcessor().ProcessRequest(url).Result);

                // set the count of all folders on the first request
                if (totalFolders < 0)
                {
                    totalFolders = Int32.Parse(queryResult["count"].ToString());
                }

                // record the UID of each folder, and its parent, if any
                foreach (JToken asset in queryResult["assets"])
                {
                    _folderIdsToNames[asset["uid"].ToString()] = asset["name"].ToString(); //TODO: tolower?

                    if (asset["parent_uid"] != null && 
                        !String.IsNullOrEmpty(asset["parent_uid"].ToString()))
                    {
                        _folderIdsToParentIds[asset["uid"].ToString()] = asset["parent_uid"].ToString();
                    }
                }

                processed += limit;
            }
            while (processed < totalFolders);
        }

        // populate _folderPathsToIds mapping paths to UIDs for existing folders
        private void MapPathsToIds()
        { 
            foreach (string uid in _folderIdsToNames.Keys)
            {
                // the end of the path to the folder (/foldername)
                string path = '/' + _folderIdsToNames[uid];
                string parentId = null;

                // if it has an ancestor, its path is longer (/parent/foldername)
                if (_folderIdsToParentIds.ContainsKey(uid))
                {
                    parentId = _folderIdsToParentIds[uid];
                }

                // process all ancestors
                while (parentId != null)
                {
                    path = "/" + _folderIdsToNames[parentId] + path;

                    if (_folderIdsToParentIds.ContainsKey(parentId))
                    {
                        parentId = _folderIdsToParentIds[parentId];
                    }
                    else
                    {
                        parentId = null;
                    }
                }

                // map the path to the folder to its ID
                _folderPathsToIds[path.TrimStart('/')] = uid;
            }
        }

        // create any folder paths that do not already exist
        private void CreateRequiredFolders()
        {
            foreach (string path in _folderPathsToIds.Keys.ToArray())
            {
                // if the folder path already exists in the CMS, skip it
                if (_folderPathsToIds[path] != null)
                {
                    continue;
                }

                // path to ensure
                string pathKey = String.Empty;

                // for tracking ancestors
                string parentId = String.Empty;

                // from the shallowest path (folder1 of folder1/folder2/folder3)
                foreach (string segment in path.Split("/"))
                {
                    // ensure slashes between folder names but not at start of path
                    pathKey = (pathKey + '/' + segment).TrimStart('/');

                    // if that folder path already exists, it is the parent of the next deepest folder (folder2)
                    // otherwise, create the folder
                    if (_folderPathsToIds.ContainsKey(pathKey) 
                        && !String.IsNullOrWhiteSpace(_folderPathsToIds[pathKey]))
                    {
                        parentId = _folderPathsToIds[pathKey];
                    }
                    else
                    {
                        // the name of the folder to create
                        JObject properties = new JObject(
                            new JProperty("name", segment));

                        // the UID of its parent folder
                        if (!String.IsNullOrEmpty(parentId))
                        {
                            properties.Add(new JProperty("parent_uid", parentId));
                        }

                        // create the folder
                        // https://www.contentstack.com/docs/developers/apis/content-management-api/#create-a-folder
                        JObject postBody = new JObject(new JProperty("asset", properties));
                        JObject result = JObject.Parse(new HttpRequestProcessor().ProcessRequest(
                            "https://api.contentstack.io/v3/assets/folders/", postBody).Result);
                        parentId = result.SelectToken("$.asset.uid").ToString();
                        _folderPathsToIds[pathKey] = parentId;
                    }
                }
            }
        }

        // remove empty folders 
        private void PruneEmptyFolders()
        {
            // process from ancestors up to children
            // because ancestors are not empty until children are deleted
            foreach(string folderPath in _folderPathsToIds.Keys.ToArray().Reverse())
            {
                // if the list of folder paths indicates that a folder has descendant folders,
                // then there is no need to count its children to know not to delete it
                if (_folderPathsToIds.Keys.Any(key => key.StartsWith(folderPath) && key != folderPath))
                {
                    continue;
                }

                // count the children of the folder
                string folderCountUrl = "https://api.contentstack.io/v3/assets?include_folders=true&include_count=true&folder=" 
                    + _folderPathsToIds[folderPath];
                JObject folderCountResults = JObject.Parse(new HttpRequestProcessor().ProcessRequest(folderCountUrl).Result);

                // if the folder has no children, then delete it
                if (folderCountResults["count"].ToString() == "0")
                {
                    string deleteUrl = "https://api.contentstack.io/v3/assets/folders/" + _folderPathsToIds[folderPath];
                    JObject deleteResults = JObject.Parse(
                        new HttpRequestProcessor().ProcessRequest(deleteUrl, /*postbody*/ null, "DELETE").Result);
                    bool success = _folderPathsToIds.Remove(folderPath);
                }
            }
        }

        public void Process(string csv)
        {
            // map each path in the CSV and each implied ancestor to null in _folderPathsToIds - trimmed folder paths to folder IDs
            MapPathsToNull(csv);

            // add existing folders to _folderIdsToNames and set _folderIdsToParentIds - folder IDs to parent IDs or null/empty string/ no entry
            AddExistingFolderData();

            // populate _folderPathsToIds - trimmed folder paths to folder IDs
            MapPathsToIds();

            // populate _folderIdsToParentIds - folder IDs to parent IDs or null/empty string/no entry
            // create folders and update _folderPathsToIds for new folders
            CreateRequiredFolders();

            // upload the binaries
            ImportOrUpdateAssets(csv);

            // remove empty folders
            PruneEmptyFolders();

            //TODO: report duplicates
        }
        
        // import or update the assets listed in the CSV file
        private void ImportOrUpdateAssets(string csv)
        {
            using (TextFieldParser parser = new TextFieldParser(csv))
            {
                parser.TextFieldType = FieldType.Delimited;
                parser.SetDelimiters(",");
                string discardHeaders = parser.ReadLine();

                while (!parser.EndOfData)
                {
                    int columnIndex = 0; ;
                    string[] fields = parser.ReadFields();
                    string filePath = fields[columnIndex++];
                    string title = fields[columnIndex++];
                    string description = fields[columnIndex++];
                    string folderPath = fields[columnIndex++];
                    string tags = fields[columnIndex++];
                    string folderUid = null;
                    string key = folderPath.TrimStart('/').TrimEnd('/').ToLower();

                    if (_folderPathsToIds.ContainsKey(key) && _folderPathsToIds[key] != null)
                    {
                        folderUid = _folderPathsToIds[key];
                    }

                    ProcessAsset(new AssetInfo(new FileInfo(filePath), title, description, folderUid, tags));
                }
            }
        }

        // import or update the assets
        private void ProcessAsset(AssetInfo assetInfo)
        {
            int processed = 0;
            int count = -1;
            int limit = 100;

            // page through assets of same size
            do
            {
                // https://www.contentstack.com/docs/developers/apis/content-delivery-api/#all-assets
                string url = "https://api.contentstack.io/v3/assets?limit="
                    + limit
                    + "&query={\"file_size\":"
                    + assetInfo.FileInfo.Length
                    + "}&skip="
                    + processed;

                if (count < 0)
                {
                    url += "&include_count=true";
                }

                JObject queryResult = JObject.Parse(new HttpRequestProcessor().ProcessRequest(url).Result);

                if (count < 0)
                {
                    count = Int32.Parse(queryResult["count"].ToString());
                }

                JToken existingAssets = queryResult["assets"];

                // if existing asset with same content exists, update it
                // otherwise, upload it
                if (existingAssets == null || !Update(assetInfo, existingAssets))
                {
                    new AssetUploader().Upload(assetInfo);
                }

                processed += limit;
            }
            while (processed < count);
        }

        // if asset with same binary content exists, update if needed; return true
        // if asset with sams binary content does not exist, return false
        private bool Update(AssetInfo assetInfo, JToken existingAssets)
        {
            foreach (JObject asset in existingAssets)
            {
                string assetUrl = asset["url"].ToString(); ;
                string uid = asset["uid"].ToString();
                byte[] assetBytes = null;
//Console.WriteLine(assetUrl.ToString());

                using (var wc = new WebClient())
                {
                    assetBytes = wc.DownloadData(assetUrl.ToString());

                    if (assetBytes.Length.ToString() != asset["file_size"].ToString())
                    {
//                        Console.WriteLine("downloaded " + assetUrl.ToString() + " " + assetBytes.Length + " does not match " + assetInfo.FileInfo.FullName + " " + assetInfo.FileInfo.Length);
                        continue;
                    }
                }

//                Console.WriteLine("Comparing " + assetInfo.FileInfo.FullName + " to binary with matching size");

                if (ContentsEquate(assetInfo.FileInfo, assetBytes))
                {
 //                   Console.WriteLine("Contents identical");

                    bool update = !(asset["title"].ToString().Equals(assetInfo.Title, StringComparison.Ordinal)
                        && asset["description"].ToString().Equals(assetInfo.Description, StringComparison.Ordinal)
                        && asset["parent_uid"].ToString().Equals(assetInfo.FolderUid, StringComparison.Ordinal));

                    if (!update)
                    {
                        int i = 0;

                        foreach (JToken jToken in asset["tags"])
                        {
                            if (assetInfo.Tags == null
                                || i >= assetInfo.Tags.Length || jToken.ToString() != assetInfo.Tags[i])
                            {
                                update = true;
                                break;
                            }

                            i++;
                        }

                        if ((!update) && assetInfo.Tags != null && i != assetInfo.Tags.Length)
                        {
                            update = true;
                        }
                   }

                    if (update)
                    {
                        string tags = String.Empty;

                        if (assetInfo.Tags != null)
                        {
                            tags = string.Join(',', assetInfo.Tags);
                        }

                        JObject properties = new JObject(
                            new JProperty("title", assetInfo.Title),
                            new JProperty("tags", tags),
                            new JProperty("description", assetInfo.Description));

                        if (!String.IsNullOrWhiteSpace(assetInfo.FolderUid))
                        {
                            properties.Add(new JProperty("parent_uid", assetInfo.FolderUid.ToString()));
                        }

                        JObject postBody = new JObject(new JProperty("asset", properties));
                        JObject updateResult = JObject.Parse(new HttpRequestProcessor().ProcessRequest(
                            "https://api.contentstack.io/v3/assets/" + uid,
                            postBody, 
                            "PUT").Result);
                    }

                    return true;
                }

//                Console.WriteLine("Contents not identical");
            }

            return false;
        }

        private const int _bufferSize = 131072;//TODO: estimated average media size

        // source buffer for file comparison
        private readonly byte[] _source = new byte[_bufferSize];

        // target buffer for file comparison
        private readonly byte[] _target = new byte[_bufferSize];

        // return true if the contents of the file are equal to those in memory, false otherwise
        public bool ContentsEquate(FileInfo fileInfo, byte[] memory)
        {
            using (FileStream fileStream = new FileStream(fileInfo.FullName, FileMode.Open))
            {
                using (MemoryStream memoryStream = new MemoryStream(memory))
                {
                    while (true)
                    {
                        int firstCount = fileStream.Read(_source, 0, _bufferSize);
                        int secondCount = memoryStream.Read(_target, 0, _bufferSize);

                        if (firstCount != secondCount)
                        {
                            return false; // sizes must differ 
                        }

                        if (firstCount == 0)
                        {
                            return true; // read entire file, contents matched
                        }

                        // faster? alternative:
                        // using System.Runtime.InteropServices;
                        // if (_source.Length == _target.Length && memcmp(bFirst, bSecond, count) == 0;
                        if (!_source.Take(firstCount).SequenceEqual(_source.Take(secondCount)))
                        {
                            return false;
                        }
                    }
                }
            }
        }

    }
}
