﻿namespace ContentstackAssetImporter
{
    using System;
    using System.IO;
    using System.Net;
    using System.Text;
    using System.Threading.Tasks;

    using Newtonsoft.Json.Linq;

    public class HttpRequestProcessor
    {
        public async Task<string> ProcessRequest(
            string Url,
            JObject payloadBody = null,
            string method = null)
        {
            // URL of HTTPS API call
            WebRequest request = (HttpWebRequest)WebRequest.Create(Url);

            // if caller specified an HTTP method
            if (method != null)
            {
                request.Method = method;
            }

            // if the request has a JSON payload (query), then encode it
            // and default the HTTP method if the caller did not specify
            if (payloadBody != null)
            {
                // if the caller did not specify an HTTP method
                if (method == null)
                {
                    request.Method = "POST"; //TODO: or default to PUT?
                }

                byte[] byteArray = Encoding.UTF8.GetBytes(payloadBody.ToString());
                request.ContentLength = byteArray.Length;

                using (Stream requestStream = request.GetRequestStream())
                {
                    requestStream.Write(byteArray, 0, byteArray.Length);
                }
            }
            else
            {
                // request has no JSON payload; default HTTP method
                if (request.Method == null)
                {
                    request.Method = "GET";
                }
            }

            request.ContentType = "application/json";

            // user agent can be useful for statics/reporting
            request.Headers["x-user-agent"] = this.ToString();

            //TODO: vendor-specific and shouldn't be hard-coded
            request.Headers["api_key"] = "//TODO:";
            request.Headers["authorization"] = "//TODO:";

            try
            {
                Console.WriteLine(request.RequestUri);
                // call the API and return its response as a string
                using (Stream responseStream =
                    ((HttpWebResponse)await request.GetResponseAsync()).GetResponseStream())
                {
                    return new StreamReader(responseStream).ReadToEnd();
                }
            }
            catch (AggregateException ex)
            {
                if (ex.InnerException != null)
                {
                    WebException wex = ex.InnerException as WebException;

                    if (wex != null)
                    {
                        using (var stream = wex.Response.GetResponseStream())
                        {
                            using (var reader = new StreamReader(stream))
                            {
                                Console.WriteLine(reader.ReadToEnd());
                            }
                        }
                    }
                }

                throw;
            }
            catch(WebException ex)
            {
                using (var stream = ex.Response.GetResponseStream())
                {
                    using (var reader = new StreamReader(stream))
                    {
                        Console.WriteLine(reader.ReadToEnd());
                    }
                }

                throw;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.GetType() + " : " + ex.Message);
                throw;
            }
        }
    }
}
