﻿namespace ContentstackAssetImporter
{
    using System.IO;

    public struct AssetInfo
    {
        public AssetInfo(FileInfo fileInfo, string title, string description, string folderUid = null, string tags = null)
        {
            FileInfo = fileInfo;
            Title = title;
            Description = description;
            FolderUid = folderUid;
            Tags = null;

            if (tags != null)
            {
                Tags = tags.Split("|");
            }
        }

        public FileInfo FileInfo;
        public string Title;
        public string Description;
        public string FolderUid;
        public string[] Tags;
    }
}
