﻿namespace ContentstackAssetImporter
{
    using System;
    using System.Collections.Specialized;
    using System.IO;
    using System.Net;
    using System.Text;
    internal class AssetUploader
    {
        public string Upload(AssetInfo assetInfo)
        {
            // marker between multipart HTTP elements
            string boundary = "---------------------------" + DateTime.Now.Ticks.ToString("x");
            byte[] boundaryBytes = Encoding.ASCII.GetBytes("\r\n--" + boundary + "\r\n");

            // https://www.contentstack.com/docs/developers/apis/content-management-api/#upload-asset
            string url = "https://api.contentstack.io/v3/assets?include_dimensions=true";
            HttpWebRequest request = (HttpWebRequest)WebRequest.Create(url);
            request.ContentType = "multipart/form-data; boundary=" + boundary;
            request.Method = "POST";
            request.KeepAlive = true;
            request.Headers["api_key"] = "//TODO:";
            request.Headers["authorization"] = "//TODO:";
            request.Headers["cache-control"] = "no-cache";

            // temporary to get size for request.ContentLength
            MemoryStream memoryStream = new MemoryStream();
            memoryStream.Write(boundaryBytes, 0, boundaryBytes.Length);

            NameValueCollection formFields = new NameValueCollection();
            formFields["asset[title]"] = assetInfo.Title; //minus any special chars or with any substitutions?
            formFields["asset[description]"] = assetInfo.Description;

            if (assetInfo.Tags != null && assetInfo.Tags.Length > 0)
            {
                formFields["asset[tags]"] = String.Join(",", assetInfo.Tags);
            }

            if (!String.IsNullOrEmpty(assetInfo.FolderUid))
            {
                formFields["asset[parent_uid]"] = assetInfo.FolderUid;
            }

            // format form element values for multipart HTTP
            string formElement = "Content-Disposition: form-data; name=\"{0}\"\r\n\r\n{1}";

            foreach (string key in formFields.Keys)
            {
                byte[] formItemBytes = Encoding.ASCII.GetBytes(String.Format(formElement, key, formFields[key]));
                memoryStream.Write(formItemBytes, 0, formItemBytes.Length);
                memoryStream.Write(boundaryBytes, 0, boundaryBytes.Length);
            }

            // get from registry if possible? Registry.GetValue(@"HKEY_CLASSES_ROOT\.pdf", "Content Type", null) as string;
            string mimeType = assetInfo.FileInfo.Extension.TrimStart('.').ToLower();

            switch(mimeType)
            {
                case "jpg":
                case "jpeg":
                    mimeType = "image/jpeg";
                    break;
                case "png":
                    mimeType = "image/png";
                    break;
                default:
                    Console.WriteLine("No MIME type for " + mimeType);
                    break;
            }

            // encode file for multipart HTTP
            byte[] fileHeaderBytes = Encoding.UTF8.GetBytes(String.Format(
                "Content-Disposition: form-data; name=\"asset[upload]\"; filename=\"{0}\"\r\nContent-Type: {1}\r\n\r\n",
                assetInfo.FileInfo.Name,
                mimeType));
            memoryStream.Write(fileHeaderBytes, 0, fileHeaderBytes.Length);

            // encode the file into the HTTP request body
            byte[] buffer = new byte[4096]; //TODO: bigger buffer? 65536?
            using (FileStream fileStream = new FileStream(assetInfo.FileInfo.FullName, FileMode.Open, FileAccess.Read))
            {
                int bytesRead = 0;

                while ((bytesRead = fileStream.Read(buffer, 0, buffer.Length)) != 0)
                {
                    memoryStream.Write(buffer, 0, bytesRead);
                }
            }

            // close the HTTP body
            byte[] footerElement = Encoding.ASCII.GetBytes("\r\n--" + boundary + "--\r\n");
            memoryStream.Write(footerElement, 0, footerElement.Length);
            request.ContentLength = memoryStream.Length;

            // debug HTTP post body
//            memoryStream.Position = 0;
//            Console.WriteLine(new StreamReader(memoryStream).ReadToEnd());

            // write memory stream to request body
            using (Stream requestStream = request.GetRequestStream())
            {
                memoryStream.Position = 0;
                byte[] tempBuffer = new byte[memoryStream.Length];
                memoryStream.Read(tempBuffer, 0, tempBuffer.Length);
                memoryStream.Close();
                requestStream.Write(tempBuffer, 0, tempBuffer.Length);
            }

            try
            {
                using (Stream responseStream = ((HttpWebResponse)
                    request.GetResponseAsync().Result).GetResponseStream())
                {
                    return new StreamReader(responseStream).ReadToEnd();
                }
            }
            catch(AggregateException ex)
            {
                if (ex.InnerException != null)
                {
                    WebException wex = ex.InnerException as WebException;

                    if (wex != null)
                    {
                        using (var stream = wex.Response.GetResponseStream())
                        {
                            using (var reader = new StreamReader(stream))
                            {
                                Console.WriteLine(reader.ReadToEnd());
                            }
                        }
                    }
                }

                throw;
            }
        }
    }
}
